using UnityEngine;
using System.Collections.Generic;
public class SnakeController : MonoBehaviour {
    public Transform segmentPrefab;
    public float moveSpeed = 6f;
    public float turnSpeed = 180f;
    private List<Transform> segments = new List<Transform>();
    private Vector3 inputDirection = Vector3.forward;
    void Start(){ segments.Add(transform); }
    void Update(){
        Vector2 input = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
        if(input.magnitude > 0.1f) inputDirection = new Vector3(input.x,0,input.y).normalized;
        if(inputDirection != Vector3.zero){
            Quaternion target = Quaternion.LookRotation(inputDirection);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, target, turnSpeed * Time.deltaTime);
        }
    }
    void FixedUpdate(){
        segments[0].position += transform.forward * moveSpeed * Time.fixedDeltaTime;
        for(int i=1;i<segments.Count;i++){
            Vector3 targetPos = segments[i-1].position - segments[i-1].forward * 0.6f;
            segments[i].position = Vector3.Lerp(segments[i].position, targetPos, 10f * Time.fixedDeltaTime);
            segments[i].rotation = Quaternion.Slerp(segments[i].rotation, segments[i-1].rotation, 10f * Time.fixedDeltaTime);
        }
    }
    public void Grow(int amount){ for(int j=0;j<amount;j++){ Transform s = Instantiate(segmentPrefab, segments[segments.Count-1].position, Quaternion.identity); segments.Add(s); } }
    void OnTriggerEnter(Collider other){
        if(other.CompareTag("Food")){ Grow(1); Destroy(other.gameObject); GameManager.Instance.AddCoins(1); }
        else if(other.CompareTag("Wall")){ GameManager.Instance.GameOver("Hit Wall"); }
        else if(other.CompareTag("Tail")){ GameManager.Instance.GameOver("Hit Tail"); }
    }
}