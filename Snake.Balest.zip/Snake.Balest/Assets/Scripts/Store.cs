using UnityEngine;
public class Store : MonoBehaviour {
    public void Buy(string id,int price){ if(GameManager.Instance.coins>=price){ GameManager.Instance.SpendCoins(price); PlayerPrefs.SetInt(id,1); PlayerPrefs.Save(); } }
    public bool IsOwned(string id){ return PlayerPrefs.GetInt(id,0)==1; }
}