using UnityEngine;
public class UIManager : MonoBehaviour {
    public static UIManager Instance; void Awake(){ Instance=this; }
    public void UpdateCoins(int coins){ /* update UI element */ }
    public void ShowGameOver(string reason){ /* show game over UI */ }
    public void ShowLoading(float progress,string tip){ /* update loading UI */ }
}