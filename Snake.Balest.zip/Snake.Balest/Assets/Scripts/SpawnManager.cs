using UnityEngine;
public class SpawnManager : MonoBehaviour {
    public GameObject foodPrefab; public float areaSize = 20f; public float spawnInterval = 1f;
    void Start(){ InvokeRepeating(nameof(SpawnFood),1f,spawnInterval); }
    void SpawnFood(){ Vector3 pos = new Vector3(Random.Range(-areaSize,areaSize),0.5f,Random.Range(-areaSize,areaSize)); Instantiate(foodPrefab,pos,Quaternion.identity); }
}