using UnityEngine;
public class GameManager : MonoBehaviour {
    public static GameManager Instance;
    public int coins=0; public int highScore=0;
    void Awake(){ if(Instance==null){ Instance=this; DontDestroyOnLoad(gameObject); Load(); } else Destroy(gameObject); }
    public void AddCoins(int a){ coins+=a; Save(); UIManager.Instance?.UpdateCoins(coins); }
    public void SpendCoins(int a){ coins=Mathf.Max(0,coins-a); Save(); UIManager.Instance?.UpdateCoins(coins); }
    public void Save(){ PlayerPrefs.SetInt("coins",coins); PlayerPrefs.SetInt("highScore",highScore); PlayerPrefs.Save(); }
    public void Load(){ coins=PlayerPrefs.GetInt("coins",0); highScore=PlayerPrefs.GetInt("highScore",0); UIManager.Instance?.UpdateCoins(coins); }
    public void GameOver(string reason){ Debug.Log("GameOver: " + reason); UnityEngine.SceneManagement.SceneManager.LoadScene("GameOver"); }
}