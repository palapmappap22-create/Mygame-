using UnityEngine;
public class ParticleManager : MonoBehaviour {
    public ParticleSystem eatFX;
    public void PlayEat(Vector3 pos){ if(eatFX) Instantiate(eatFX,pos,Quaternion.identity); }
}