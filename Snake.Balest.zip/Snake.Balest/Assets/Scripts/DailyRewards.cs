using UnityEngine;
using System;
public class DailyRewards : MonoBehaviour {
    public int dailyAmount = 50;
    public bool Claim(){
        string key = "lastDaily";
        string last = PlayerPrefs.GetString(key,""); string today = DateTime.Now.ToString("yyyy-MM-dd");
        if(last==today) return false;
        PlayerPrefs.SetString(key,today); PlayerPrefs.Save();
        GameManager.Instance.AddCoins(dailyAmount);
        return true;
    }
}