using UnityEngine;
public class PauseMenu : MonoBehaviour {
    public static bool GameIsPaused = false;
    public GameObject pauseUI;
    public void Toggle(){
        GameIsPaused = !GameIsPaused;
        pauseUI.SetActive(GameIsPaused);
        Time.timeScale = GameIsPaused?0:1;
    }
    public void Resume(){ Toggle(); }
    public void Quit(){ Time.timeScale=1; UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu"); }
}