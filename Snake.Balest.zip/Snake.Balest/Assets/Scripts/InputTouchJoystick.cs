using UnityEngine;
public class InputTouchJoystick : MonoBehaviour {
    public static Vector2 Direction;
    void Update(){
        if(Input.touchCount>0){
            Touch t = Input.GetTouch(0);
            Direction = new Vector2(t.position.x - Screen.width/2, t.position.y - Screen.height/2).normalized;
        } else Direction = Vector2.zero;
    }
}