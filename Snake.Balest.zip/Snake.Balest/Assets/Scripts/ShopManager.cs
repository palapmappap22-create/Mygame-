using UnityEngine;
public class ShopManager : MonoBehaviour {
    public void Buy(string id,int price){ if(GameManager.Instance.coins>=price){ GameManager.Instance.SpendCoins(price); PlayerPrefs.SetInt(id,1); PlayerPrefs.Save(); Debug.Log("Bought " + id);} else Debug.Log("Not enough coins"); }
    public bool Owned(string id){ return PlayerPrefs.GetInt(id,0)==1; }
}