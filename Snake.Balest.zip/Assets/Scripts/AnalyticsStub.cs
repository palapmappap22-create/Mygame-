using UnityEngine;
public static class AnalyticsStub {
    public static void Log(string ev, string param=""){ Debug.Log("Analytics: "+ev+" -> "+param); }
}