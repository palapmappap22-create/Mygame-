using UnityEngine;
public class TutorialManager : MonoBehaviour {
    public string[] steps;
    int idx=0;
    public void Next(){ idx++; if(idx>=steps.Length) UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu"); else Debug.Log(steps[idx]); }
}