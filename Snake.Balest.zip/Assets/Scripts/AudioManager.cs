using UnityEngine;
public class AudioManager : MonoBehaviour {
    public static AudioManager Instance;
    public AudioClip bgMusic;
    public AudioClip eatSound;
    public AudioClip hitSound;
    AudioSource source;
    void Awake(){ if(Instance==null){ Instance=this; DontDestroyOnLoad(gameObject); source = gameObject.AddComponent<AudioSource>(); } else Destroy(gameObject); }
    public void PlayMusic(){ if(bgMusic==null) return; source.clip = bgMusic; source.loop=true; source.Play(); }
    public void PlaySfx(AudioClip c){ if(c==null) return; source.PlayOneShot(c); }
}