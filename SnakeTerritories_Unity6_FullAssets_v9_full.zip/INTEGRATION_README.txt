Integration README - Automated helper (v8)
=========================================

This package adds 'asset_installer.sh' to help you fetch the recommended free assets.
Because some asset sources require login (Mixamo) or manual selection (best-fit model),
the script provides instructions and tries to download simple CC0 test files automatically.

Recommended flow:
1. Copy this entire project folder to a computer (Windows/Mac/Linux) with internet.
2. Open a terminal in the folder and run:
   chmod +x asset_installer.sh
   ./asset_installer.sh
3. Follow the printed manual instructions to download Mixamo and Kenney packs.
4. After finishing, open the project in Unity 6 LTS, import the downloaded assets (they're already placed under Assets/Art/Models/3D_Placeholders and Assets/Audio).
5. Create Prefabs as instructed in Assets/Art/Models/3D_Placeholders/hero_placeholder_instructions.txt and SceneSetup_Instructions.txt
6. Build APK locally or upload this project folder to Appcircle/Codemagic/Unity Cloud Build.

If you'd rather I integrate the assets for you:
- Upload the asset files (FBX/GLB/ZIP for models, WAV/MP3 for audio) here or provide download links.
- I will import them, create Prefabs and Animator Controllers, and return a final ZIP (ready-to-build).

