   #!/bin/bash
   # Asset installer for SnakeTerritories project (v8)
   # This script helps download recommended free assets and place them into the Unity project.
   # Run this on a machine with internet and 'unzip' permissions.
   #
   # USAGE:
   # 1) Put this project folder on your machine.
   # 2) Run: chmod +x asset_installer.sh
   # 3) Run: ./asset_installer.sh
   #
   # The script will attempt to download assets from recommended sources.
   # If a URL fails (requires login or changed), the script will skip it and print manual instructions.

   set -e
   BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
   ASSETS_DIR="$BASE_DIR/Assets/Art/Models/3D_Placeholders"
   AUDIO_DIR="$BASE_DIR/Assets/Audio"
   UI_DIR="$BASE_DIR/Assets/UI/Icons"

   mkdir -p "$ASSETS_DIR" "$AUDIO_DIR" "$UI_DIR"

   echo "\n== Asset installer started ==\n"

   # 1) Download Kenney Fantasy Environment (example)
   echo "Downloading Kenney Fantasy 3D Pack (sample) ..."
   KENNEY_URL="https://kenney.nl/assets/royal-animals"
   echo "Please manually download a Kenney Fantasy/Environment pack from: $KENNEY_URL"
   echo "After downloading, extract the models/textures into: $ASSETS_DIR and $BASE_DIR/Assets/Art/Textures"


   # 2) Mixamo character - requires login; give instructions
   echo "Mixamo characters require Adobe login. Manual step:" 
   echo " - Go to https://www.mixamo.com/ , pick a fantasy hero model and animations (Idle, Run, Attack)."
   echo " - Download FBX for Unity (with skin) and save the .fbx files into: $ASSETS_DIR"
   echo

   # 3) Example free dragon from Sketchfab (manual)
   echo "Sketchfab CC0 models (Dragon) - manual step:"
   echo " - Search Sketchfab for 'dragon low poly downloadable' and download a CC0 model.
- Place the model files into: $ASSETS_DIR"


   # 4) Audio (OpenGameArt / FreePD)
   echo "Downloading example audio files (if available)..."
   # Example placeholder: attempt to download a small CC0 sound (if URL changes, skip)
   SFX_URL="https://opengameart.org/sites/default/files/button_click_0.wav"
   echo "Attempting to download example button click from OpenGameArt..."
   if curl -sSf -o "$AUDIO_DIR/button_click.wav" "$SFX_URL"; then
       echo "Downloaded button_click.wav"
   else
       echo "Could not download example sound automatically; please download from OpenGameArt and place into: $AUDIO_DIR"
   fi

   # 5) UI icons (Kenney)
   echo "Please download Kenney UI pack (free) and place icons into: $UI_DIR"
   echo "Kenney UI assets: https://kenney.nl/assets/ui-pack"

   echo "\n== Installer finished ==\n"
   echo "If you want, upload the downloaded asset files here and I will integrate them into the project and return a final ZIP ready for build."
   echo "Or run Unity, import the files from the Assets folder, create Prefabs as instructed in README, then Build APK or upload to Cloud Build."

