using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public TerritoryManager territoryManager;
    public UIManager uiManager;

    void Awake(){ if (Instance==null) Instance=this; else Destroy(gameObject); }
    void Start(){ uiManager.ShowMainMenu(); }
    public void StartGame(){ uiManager.ShowInGameUI(); }
    public void EndGame(){ uiManager.ShowGameOver(); }
}
