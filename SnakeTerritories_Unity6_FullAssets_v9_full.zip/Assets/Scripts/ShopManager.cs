using UnityEngine;
using System.Collections.Generic;

// Simple shop manager placeholder: holds items, prices and handles purchases (local currency).
public class ShopManager : MonoBehaviour
{
    public class ShopItem { public string id; public string title; public int price; public string prefabName; }
    public List<ShopItem> items = new List<ShopItem>()
    {
        new ShopItem(){ id="skin_red", title="Red Skin", price=100, prefabName="Skin_Red" },
        new ShopItem(){ id="skin_fire", title="Fire Tail", price=500, prefabName="Tail_Fire" }
    };

    public int playerCoins = 0;

    public bool Purchase(string itemId)
    {
        ShopItem item = items.Find(i=>i.id==itemId);
        if (item==null) return false;
        if (playerCoins < item.price) return false;
        playerCoins -= item.price;
        // grant item: save ownership in PlayerPrefs (simple)
        PlayerPrefs.SetInt("OWN_"+item.id, 1);
        PlayerPrefs.Save();
        Debug.Log("Purchased: " + item.title);
        return true;
    }

    public bool IsOwned(string itemId) => PlayerPrefs.GetInt("OWN_"+itemId,0)==1;
}
