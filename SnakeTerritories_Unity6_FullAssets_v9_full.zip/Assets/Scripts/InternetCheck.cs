        using UnityEngine;
        using UnityEngine.Networking;
        using System.Collections;

        public class InternetCheck : MonoBehaviour
        {
            public string testUrl = "https://www.google.com";
            public float timeout = 3f;
            public IEnumerator Check(System.Action<bool> callback)
            {
                using (UnityWebRequest req = UnityWebRequest.Head(testUrl))
                {
                    req.timeout = (int)timeout;
                    yield return req.SendWebRequest();
#if UNITY_2020_1_OR_NEWER
                    bool ok = req.result == UnityWebRequest.Result.Success;
#else
                    bool ok = !req.isNetworkError && !req.isHttpError;
#endif
                    callback?.Invoke(ok);
                }
            }
        }
