using UnityEngine;
using System;
public class DailyRewards : MonoBehaviour
{
    private const string LAST_CLAIM = "DT_LAST_CLAIM";
    private const string STREAK = "DT_STREAK";
    public int[] rewards = new int[] {10,20,50,100,200,500,1000};
    public bool CanClaim(out int dayIndex)
    {
        long last = Convert.ToInt64(PlayerPrefs.GetString(LAST_CLAIM, "0"));
        DateTime lastDate = DateTime.FromBinary(last==0?0:last);
        DateTime today = DateTime.UtcNow.Date;
        if (last==0) { dayIndex=0; return true; }
        if (today>lastDate) { dayIndex = (PlayerPrefs.GetInt(STREAK,0))%rewards.Length; return true; }
        dayIndex = -1; return false;
    }
    public void Claim()
    {
        if (CanClaim(out int idx))
        {
            int val = rewards[idx];
            PlayerPrefs.SetString(LAST_CLAIM, DateTime.UtcNow.Date.ToBinary().ToString());
            PlayerPrefs.SetInt(STREAK, (PlayerPrefs.GetInt(STREAK,0)+1));
            PlayerPrefs.Save();
            Debug.Log("Daily reward claimed: " + val);
        }
        else Debug.Log("Already claimed today");
    }
}
