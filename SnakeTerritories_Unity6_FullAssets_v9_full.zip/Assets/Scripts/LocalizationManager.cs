using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System;

// Loads JSON files from Assets/Localization and provides GetText(key).
public class LocalizationManager : MonoBehaviour
{
    public static LocalizationManager Instance;
    public string defaultLanguage = "en";
    public string currentLanguage;
    private Dictionary<string,string> texts = new Dictionary<string,string>();
    private const string PREF_LANG = "GAME_LANG";

    void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }
        DontDestroyOnLoad(gameObject);
        // Load language (PlayerPrefs or system)
        string lang = PlayerPrefs.GetString(PREF_LANG, "");
        if (string.IsNullOrEmpty(lang))
        {
            // try system language
            var sys = Application.systemLanguage.ToString().ToLower();
            if (sys.StartsWith("arabic") || sys.StartsWith("arab")) lang = "ar";
            else lang = "en";
        }
        LoadLanguage(lang);
    }

    public void LoadLanguage(string lang)
    {
        currentLanguage = lang;
        texts.Clear();
        string path = Path.Combine(Application.dataPath, "Localization", lang + ".json");
        if (!File.Exists(path))
        {
            Debug.LogWarning("Localization file not found: " + path + ", falling back to default."); 
            path = Path.Combine(Application.dataPath, "Localization", defaultLanguage + ".json");
        }
        try
        {
            string json = File.ReadAllText(path);
            var dict = JsonUtility.FromJson<LocalizationContainer>("{\"items\":" + json + "}").ToDictionary();
            texts = dict;
        }
        catch(Exception e){ Debug.LogError("Failed to load localization: " + e.Message); }
    }

    [Serializable]
    private class LocalizationItem { public string key; public string value; }
    [Serializable]
    private class LocalizationContainer { public LocalizationItem[] items; 
        public Dictionary<string,string> ToDictionary(){ var d = new Dictionary<string,string>(); if(items==null) return d; foreach(var i in items) d[i.key]=i.value; return d; } }

    public string GetText(string key)
    {
        if (texts.ContainsKey(key)) return texts[key];
        return key;
    }

    public void SetLanguage(string lang)
    {
        LoadLanguage(lang);
        PlayerPrefs.SetString(PREF_LANG, lang);
        PlayerPrefs.Save();
        // Notify UI elements: find all UITextLocalized and refresh
        var list = FindObjectsOfType<UITextLocalized>();
        foreach(var ui in list) ui.Refresh();
    }
}
