using UnityEngine;

// Simple currency manager using PlayerPrefs
public class CurrencyManager : MonoBehaviour
{
    public static CurrencyManager Instance;
    private const string COINS_KEY = "PLAYER_COINS";
    void Awake(){ if (Instance==null) Instance=this; else Destroy(gameObject); DontDestroyOnLoad(gameObject); }
    public int GetCoins(){ return PlayerPrefs.GetInt(COINS_KEY, 0); }
    public void AddCoins(int amount){ int v = GetCoins()+amount; PlayerPrefs.SetInt(COINS_KEY, v); PlayerPrefs.Save(); }
    public bool SpendCoins(int amount){ int v = GetCoins(); if (v<amount) return false; PlayerPrefs.SetInt(COINS_KEY, v-amount); PlayerPrefs.Save(); return true; }
    public void SetCoins(int amount){ PlayerPrefs.SetInt(COINS_KEY, amount); PlayerPrefs.Save(); }
}
