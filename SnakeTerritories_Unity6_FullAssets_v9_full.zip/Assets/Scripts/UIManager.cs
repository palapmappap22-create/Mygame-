using UnityEngine;

public class UIManager : MonoBehaviour
{
    public GameObject mainMenu, inGameUI, gameOverUI, shopUI, dailyUI;
    public void ShowMainMenu(){ mainMenu.SetActive(true); inGameUI.SetActive(false); gameOverUI.SetActive(false); }
    public void ShowInGameUI(){ mainMenu.SetActive(false); inGameUI.SetActive(true); gameOverUI.SetActive(false); }
    public void ShowGameOver(){ mainMenu.SetActive(false); inGameUI.SetActive(false); gameOverUI.SetActive(true); }
    public void ShowShop(){ shopUI.SetActive(true); }
    public void ShowDaily(){ dailyUI.SetActive(true); }
}
