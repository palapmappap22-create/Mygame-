using UnityEngine;
using System.Collections.Generic;

public class TerritoryManager : MonoBehaviour
{
    private HashSet<Vector2Int> owned = new HashSet<Vector2Int>();
    public float tileSize = 1f;

    public void Claim(Vector3 pos)
    {
        Vector2Int key = new Vector2Int(Mathf.FloorToInt(pos.x / tileSize), Mathf.FloorToInt(pos.z / tileSize));
        if (!owned.Contains(key)) owned.Add(key);
    }

    public int OwnedCount() => owned.Count;
}
