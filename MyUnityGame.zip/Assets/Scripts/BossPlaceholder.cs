using UnityEngine;
public class BossPlaceholder : MonoBehaviour
{
    public int health = 100;
    public void TakeDamage(int d){ health -= d; if (health<=0) Die(); }
    void Die(){ Debug.Log("Boss defeated"); Destroy(gameObject); }
}
