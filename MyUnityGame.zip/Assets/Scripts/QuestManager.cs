using UnityEngine;
using System.Collections.Generic;
public class QuestManager : MonoBehaviour
{
    public List<string> dailyQuests = new List<string>() { "Collect 50 coins", "Claim 1 chest", "Occupy 10 tiles" };
    public void CompleteQuest(int index){ Debug.Log("Quest completed: " + dailyQuests[index]); }
}
