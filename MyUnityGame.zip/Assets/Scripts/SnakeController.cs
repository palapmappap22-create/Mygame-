using UnityEngine;
using System.Collections.Generic;

public class SnakeController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float turnSpeed = 180f;
    public Transform segmentPrefab;
    public int initialSize = 3;
    private List<Transform> segments = new List<Transform>();

    void Start()
    {
        segments.Add(transform);
        for (int i = 0; i < initialSize - 1; i++) Grow();
    }

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        transform.Rotate(Vector3.up * h * turnSpeed * Time.deltaTime);
        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    }

    public void Grow()
    {
        if (segmentPrefab == null) return;
        Transform seg = Instantiate(segmentPrefab, segments[segments.Count-1].position - segments[segments.Count-1].forward*0.5f, Quaternion.identity);
        seg.localScale = segments[0].localScale * 0.9f;
        segments.Add(seg);
    }
}
