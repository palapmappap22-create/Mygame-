using UnityEngine;
using UnityEngine.SceneManagement;

// LobbyController: simple waiting area logic: enter lobby, show player avatar, start game when player presses Start.
public class LobbyController : MonoBehaviour
{
    public string nextScene = "Main";
    public float autoStartDelay = 0f; // if >0, auto start after delay

    void Start()
    {
        if (autoStartDelay>0f) Invoke("StartGame", autoStartDelay);
    }

    public void StartGame()
    {
        SceneManager.LoadScene(nextScene);
    }

    public void OpenShop()
    {
        // show shop UI (hooked in UIManager)
        UIManager ui = FindObjectOfType<UIManager>();
        if (ui!=null) ui.ShowShop();
    }

    public void OpenSettings()
    {
        UIManager ui = FindObjectOfType<UIManager>();
        if (ui!=null) ui.ShowMainMenu(); // replace with settings popup call
    }
}
