using UnityEngine;
using UnityEngine.SceneManagement;

// Simple tutorial flow: shows steps, waits for player action, proceeds to next step then start main level.
public class TutorialController : MonoBehaviour
{
    public string nextScene = "Level1";
    private int step = 0;
    void Start(){ ShowStep(); }
    void ShowStep(){ Debug.Log("Tutorial step " + step); /* Hook UI updates here */ }
    public void NextStep(){ step++; if (step>2) StartCoroutine(EndTutorial()); else ShowStep(); }
    System.Collections.IEnumerator EndTutorial(){ yield return new WaitForSeconds(0.3f); SceneManager.LoadScene(nextScene); }
}
