#!/bin/bash
if [ -f "$1" ]; then
  unzip -o "$1" -d .
else
  echo "Zip not found: $1" >&2; exit 1
fi
