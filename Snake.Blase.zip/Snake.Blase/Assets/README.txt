SnakeTerritories - Unity 6.0 LTS Starter (With Simple Placeholder Assets)
======================================================================

This ZIP contains a Unity project skeleton compatible with Unity 6.0 LTS.
It includes simple placeholder 3D models (OBJ) and silent audio placeholders so the project
behaves like a 'complete' project out of the box. Replace placeholders with higher-quality
models/sounds (Mixamo, Unity Asset Store) for production.

QUICK START:
1. Install Unity 6.0 LTS via Unity Hub.
2. Create a new 3D project in Unity 6.0 LTS.
3. Close Unity. Copy 'Assets' and 'ProjectSettings' from this ZIP into the new project folder (overwrite when asked).
4. Open Unity. Create or open the scene Assets/Scenes/Main.unity (placeholder file exists — open it and save a real scene).
5. Drag the prefab placeholders from Assets/Prefabs into the scene (SnakePrefab, EnemyPrefab, BossPrefab).
6. Press Play. The placeholders are simple cube-based models so the game runs without external asset downloads.

WHERE TO GET BETTER ASSETS:
- Mixamo (characters & animations, free): https://www.mixamo.com/
- Unity Asset Store (free and paid packs): https://assetstore.unity.com/
- Kenney.nl (free game assets): https://kenney.nl/

AD & SDK NOTES:
- AdManager.cs contains stubs. Add AdMob or Unity Ads SDKs to Assets/Plugins and follow their documentation.
- Place your ad unit ids inside Assets/Scripts/AdManager.cs after integrating SDK.

LICENSE & ASSET NOTES:
- The placeholder OBJ models and silent WAVs included here are created for this starter project and are free to use.
- Replace with licensed assets for production releases.

Troubleshooting: If you see console errors on opening the project, paste the first 2 lines here and I'll help.
