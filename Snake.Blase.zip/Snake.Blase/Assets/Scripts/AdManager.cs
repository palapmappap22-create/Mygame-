using UnityEngine;
public class AdManager : MonoBehaviour
{
    public static AdManager Instance;
    void Awake(){ if (Instance==null) Instance=this; else Destroy(gameObject); }
    public void ShowInterstitial(){ Debug.Log("[AdManager] ShowInterstitial (stub)"); }
    public void ShowRewarded(System.Action<bool> callback){ Debug.Log("[AdManager] ShowRewarded (stub)"); callback?.Invoke(true); }
}
