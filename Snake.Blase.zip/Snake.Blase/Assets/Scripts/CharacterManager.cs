using UnityEngine;
using System.Collections.Generic;

// Manages available characters/skins and purchase state
public class CharacterManager : MonoBehaviour
{
    public static CharacterManager Instance;
    public List<Character> characters = new List<Character>()
    {
        new Character(){ id="hero01", title="Hero Basic", price=0, prefabName="Hero01" },
        new Character(){ id="hero02", title="Swift Runner", price=500, prefabName="Hero02" },
        new Character(){ id="hero03", title="Mighty", price=1000, prefabName="Hero03" }
    };
    private const string SELECTED_KEY = "CHAR_SELECTED";

    void Awake(){ if (Instance==null) Instance=this; else Destroy(gameObject); DontDestroyOnLoad(gameObject); EnsureDefaults(); }

    [System.Serializable]
    public class Character{ public string id; public string title; public int price; public string prefabName; }

    void EnsureDefaults()
    {
        // unlock first character by default
        if (PlayerPrefs.GetInt("OWN_"+characters[0].id, 0)==0) PlayerPrefs.SetInt("OWN_"+characters[0].id,1);
        if (PlayerPrefs.HasKey(SELECTED_KEY)==false) PlayerPrefs.SetString(SELECTED_KEY, characters[0].id);
    }

    public bool IsOwned(string id) => PlayerPrefs.GetInt("OWN_"+id,0)==1;
    public bool Purchase(string id)
    {
        var c = characters.Find(x=>x.id==id);
        if (c==null) return false;
        if (IsOwned(id)) return true;
        if (CurrencyManager.Instance==null) return false;
        if (CurrencyManager.Instance.SpendCoins(c.price)){ PlayerPrefs.SetInt("OWN_"+id,1); PlayerPrefs.Save(); return true; }
        return false;
    }

    public void Select(string id)
    {
        if (!IsOwned(id)) return;
        PlayerPrefs.SetString(SELECTED_KEY, id);
        PlayerPrefs.Save();
    }

    public string GetSelected() => PlayerPrefs.GetString(SELECTED_KEY, characters[0].id);
}
