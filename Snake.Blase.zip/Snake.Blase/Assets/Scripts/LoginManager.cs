using UnityEngine;

// Simple local LoginManager: stores player name and triggers daily reward UI
public class LoginManager : MonoBehaviour
{
    private const string PLAYER_NAME = "PLAYER_NAME";
    public string playerName = "Player";

    void Start()
    {
        playerName = PlayerPrefs.GetString(PLAYER_NAME, "Player");
    }

    public void SetName(string name)
    {
        playerName = name;
        PlayerPrefs.SetString(PLAYER_NAME, name);
        PlayerPrefs.Save();
    }

    public string GetName() => playerName;

    public void OpenDailyRewards()
    {
        UIManager ui = FindObjectOfType<UIManager>();
        if (ui!=null) ui.ShowDaily();
    }
}
