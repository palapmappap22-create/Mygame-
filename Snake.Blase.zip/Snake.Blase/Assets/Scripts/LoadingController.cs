using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

// LoadingController: shows progress and waits for player tap/click when loading finished.
public class LoadingController : MonoBehaviour
{
    public string sceneToLoad = "Main"; // target scene to load
    public Slider progressBar;
    public Text progressText; // or TextMeshProUGUI if using TMP
    public GameObject tapToContinueText; // optional UI element that shows 'Tap to continue'

    void Start()
    {
        if (tapToContinueText!=null) tapToContinueText.SetActive(false);
        StartCoroutine(LoadAsync());
    }

    IEnumerator LoadAsync()
    {
        AsyncOperation op = SceneManager.LoadSceneAsync(sceneToLoad);
        op.allowSceneActivation = false;
        bool readyToActivate = false;

        while (!op.isDone)
        {
            float progress = Mathf.Clamp01(op.progress / 0.9f);
            if (progressBar != null) progressBar.value = progress;
            if (progressText != null) progressText.text = (int)(progress * 100f) + "%";

            if (op.progress >= 0.9f && !readyToActivate)
            {
                // Show 'tap to continue' and wait for user input
                readyToActivate = true;
                if (tapToContinueText!=null) tapToContinueText.SetActive(true);
            }

            if (readyToActivate && (Input.GetMouseButtonDown(0) || Input.touchCount>0))
            {
                op.allowSceneActivation = true;
            }

            yield return null;
        }
    }
}
