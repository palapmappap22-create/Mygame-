using UnityEngine;

// Simple settings manager for audio levels and basic toggles.
public class SettingsManager : MonoBehaviour
{
    private const string VOL_MUSIC = "SET_VOL_MUSIC";
    private const string VOL_SFX = "SET_VOL_SFX";
    private const string TILT_CONTROLS = "SET_TILT";

    public float musicVolume = 1f;
    public float sfxVolume = 1f;

    void Start()
    {
        musicVolume = PlayerPrefs.GetFloat(VOL_MUSIC,1f);
        sfxVolume = PlayerPrefs.GetFloat(VOL_SFX,1f);
    }

    public void SetMusicVolume(float v){ musicVolume = v; PlayerPrefs.SetFloat(VOL_MUSIC,v); PlayerPrefs.Save(); AudioManager.Instance?.PlayMusic("menu"); }
    public void SetSFXVolume(float v){ sfxVolume = v; PlayerPrefs.SetFloat(VOL_SFX,v); PlayerPrefs.Save(); }
    public void SetTiltControls(bool on){ PlayerPrefs.SetInt(TILT_CONTROLS, on?1:0); PlayerPrefs.Save(); }
}


public void SetLanguage(string code)
{
    LocalizationManager.Instance?.SetLanguage(code);
}
