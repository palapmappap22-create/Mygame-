using UnityEngine;

// Simple Character Animator Hook - call SetState("run") etc.
public class CharacterAnimatorHook : MonoBehaviour
{
    private Animator animator;
    void Awake(){ animator = GetComponent<Animator>(); }
    public void SetState(string state)
    {
        if (animator==null) return;
        animator.Play(state);
    }
}
