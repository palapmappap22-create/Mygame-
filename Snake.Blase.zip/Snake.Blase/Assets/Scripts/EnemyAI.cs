using UnityEngine;
public class EnemyAI : MonoBehaviour
{
    public float speed = 2f;
    private Transform player;
    void Start(){ player = GameObject.FindWithTag("Player")?.transform; }
    void Update(){ if (player==null) return; transform.position = Vector3.MoveTowards(transform.position, player.position, speed*Time.deltaTime); }
}
