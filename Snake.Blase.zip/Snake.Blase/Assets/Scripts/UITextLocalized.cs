using UnityEngine;
using UnityEngine.UI;

// Attach to Text (legacy) or TMP and set key. It will update text from LocalizationManager.
public class UITextLocalized : MonoBehaviour
{
    public string key;
    private Text uiText;
    void Awake(){ uiText = GetComponent<Text>(); Refresh(); }
    public void Refresh(){ if (uiText!=null) uiText.text = LocalizationManager.Instance!=null ? LocalizationManager.Instance.GetText(key) : key; }
}
