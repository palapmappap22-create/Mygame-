using UnityEngine;
using UnityEngine.UI;

// Simple UI updater for coins display
public class CoinsUI : MonoBehaviour
{
    public Text coinsText;
    void Start(){ UpdateUI(); }
    public void UpdateUI(){ if (coinsText!=null) coinsText.text = LocalizationManager.Instance.GetText("LBL_COINS") + ": " + CurrencyManager.Instance.GetCoins(); }
    void OnEnable(){ UpdateUI(); }
}
