Snake3D Advanced skeleton project. Placeholder assets and many skins included.
