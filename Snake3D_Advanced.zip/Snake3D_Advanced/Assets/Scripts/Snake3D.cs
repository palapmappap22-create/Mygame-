using UnityEngine;
using System.Collections.Generic;
public class Snake3D : MonoBehaviour {
    public Transform segmentPrefab;
    public float moveSpeed = 5f;
    public float segmentDistance = 0.5f;
    private List<Transform> segments = new List<Transform>();
    private Vector3 direction = Vector3.forward;
    void Start(){ segments.Add(this.transform); }
    void Update(){
        if (Input.GetKeyDown(KeyCode.W)) direction = Vector3.forward;
        if (Input.GetKeyDown(KeyCode.S)) direction = Vector3.back;
        if (Input.GetKeyDown(KeyCode.A)) direction = Vector3.left;
        if (Input.GetKeyDown(KeyCode.D)) direction = Vector3.right;
    }
    void FixedUpdate(){
        Vector3 prev = segments[0].position;
        segments[0].position += direction * moveSpeed * Time.fixedDeltaTime;
        for(int i=1;i<segments.Count;i++){
            Vector3 temp = segments[i].position;
            segments[i].position = Vector3.Lerp(segments[i].position, prev, 0.5f);
            prev = temp;
        }
    }
    public void Grow(){ Transform s = Instantiate(segmentPrefab, segments[segments.Count-1].position, Quaternion.identity); segments.Add(s); }
}