using UnityEngine;
public class GameManager : MonoBehaviour {
    public static GameManager Instance;
    public int coins = 0;
    public int highScore = 0;
    void Awake(){ if (Instance==null){ Instance=this; DontDestroyOnLoad(gameObject); Load(); } else Destroy(gameObject); }
    public void AddCoins(int a){ coins += a; Save(); }
    public void SpendCoins(int a){ coins = Mathf.Max(0, coins - a); Save(); }
    public void Save(){ PlayerPrefs.SetInt("coins", coins); PlayerPrefs.SetInt("highScore", highScore); PlayerPrefs.Save(); }
    public void Load(){ coins = PlayerPrefs.GetInt("coins",0); highScore = PlayerPrefs.GetInt("highScore",0); }
    public bool ClaimDaily(){ string k="lastDaily"; string last = PlayerPrefs.GetString(k,""); string today = System.DateTime.Now.ToString("yyyy-MM-dd"); if (last==today) return false; PlayerPrefs.SetString(k,today); AddCoins(50); return true; }
}