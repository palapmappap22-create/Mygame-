using UnityEngine;
public class Store : MonoBehaviour {
    public void Buy(string skinId, int price){
        if (GameManager.Instance.coins >= price){ GameManager.Instance.SpendCoins(price); PlayerPrefs.SetInt(skinId,1); PlayerPrefs.Save(); Debug.Log("Bought " + skinId); }
    }
    public bool IsOwned(string skinId){ return PlayerPrefs.GetInt(skinId,0)==1; }
}