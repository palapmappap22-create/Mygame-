using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
public class LoadingController : MonoBehaviour {
    public string nextScene = "MainMenu";
    void Start(){ StartCoroutine(DoLoad()); }
    IEnumerator DoLoad(){ float t=0f; while(t<2f){ t+=Time.deltaTime; yield return null; } SceneManager.LoadScene(nextScene); }
}