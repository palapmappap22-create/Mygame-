using UnityEngine;
public class CameraController : MonoBehaviour {
    public Transform target;
    public Vector3 offset = new Vector3(0,6,-8);
    public float followSpeed = 5f;
    void LateUpdate(){
        if (target==null) return;
        Vector3 desired = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desired, followSpeed * Time.deltaTime);
        transform.LookAt(target.position);
    }
}