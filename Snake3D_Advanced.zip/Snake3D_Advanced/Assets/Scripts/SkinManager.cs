using UnityEngine;
public class SkinManager : MonoBehaviour {
    public static SkinManager Instance;
    public string currentSkin = "skin_1";
    void Awake(){ if (Instance==null){ Instance=this; DontDestroyOnLoad(gameObject);} else Destroy(gameObject); }
    public void SetSkin(string id){ currentSkin=id; PlayerPrefs.SetString("skin",id); }
    public void LoadSkin(){ currentSkin = PlayerPrefs.GetString("skin","skin_1"); }
}