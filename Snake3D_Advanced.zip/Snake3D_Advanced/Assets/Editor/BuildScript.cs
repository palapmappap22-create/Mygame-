using UnityEditor;
public class BuildScript {
    public static void BuildAndroid() {
        string[] scenes = { "Assets/Scenes/GameScene.unity" };
        string path = "build/android/Snake3D.apk";
        BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
        buildPlayerOptions.scenes = scenes;
        buildPlayerOptions.locationPathName = path;
        buildPlayerOptions.target = BuildTarget.Android;
        buildPlayerOptions.options = BuildOptions.None;
        BuildPipeline.BuildPlayer(buildPlayerOptions);
    }
}